package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"syscall"
	"time"
)

type AppConfig struct {
	Name        string `json:"name"`
	Package     string `json:"package"`
	Enabled     bool   `json:"enabled"`
	AutoRestart bool   `json:"auto_restart"`
}

type Config struct {
	RefreshSeconds int         `json:"refresh_seconds"`
	LogFile        string      `json:"log_file"`
	Apps           []AppConfig `json:"apps"`
}

type AppStatus struct {
	App     AppConfig
	Running bool
	PIDs    string
	Action  string
}

var (
	configPath = "config.json"
	cfg        Config
)

func main() {
	if err := ensureConfig(); err != nil {
		fmt.Fprintln(os.Stderr, "Config error:", err)
		os.Exit(1)
	}
	if err := loadConfig(); err != nil {
		fmt.Fprintln(os.Stderr, "Config error:", err)
		os.Exit(1)
	}

	logf("INFO", "nefrejoin-go started")
	fmt.Println("nefrejoin-go | Termux")
	fmt.Println("กด Ctrl+C เพื่อออกจากโปรแกรม")
	time.Sleep(900 * time.Millisecond)

	quit := make(chan os.Signal, 1)
	signal.Notify(quit, os.Interrupt, syscall.SIGTERM)

	interval := time.Duration(cfg.RefreshSeconds) * time.Second
	if interval < time.Second {
		interval = 3 * time.Second
	}
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	renderAndCheck()
	for {
		select {
		case <-ticker.C:
			renderAndCheck()
		case <-quit:
			logf("INFO", "program stopped by user")
			fmt.Println("\nปิดโปรแกรมแล้ว")
			return
		}
	}
}

func ensureConfig() error {
	if _, err := os.Stat(configPath); err == nil {
		return nil
	}
	defaultCfg := Config{
		RefreshSeconds: 3,
		LogFile:        "logs/nefrejoin.log",
		Apps: []AppConfig{
			{
				Name:        "Roblox",
				Package:     "com.roblox.client",
				Enabled:     true,
				AutoRestart: false,
			},
		},
	}
	if err := os.MkdirAll("logs", 0755); err != nil {
		return err
	}
	data, err := json.MarshalIndent(defaultCfg, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(configPath, data, 0644)
}

func loadConfig() error {
	data, err := os.ReadFile(configPath)
	if err != nil {
		return err
	}
	if err := json.Unmarshal(data, &cfg); err != nil {
		return fmt.Errorf("อ่าน config.json ไม่ได้: %w", err)
	}
	if cfg.RefreshSeconds < 1 {
		cfg.RefreshSeconds = 3
	}
	if strings.TrimSpace(cfg.LogFile) == "" {
		cfg.LogFile = "logs/nefrejoin.log"
	}
	if len(cfg.Apps) == 0 {
		return errors.New("ยังไม่มีรายการ apps ใน config.json")
	}
	for i := range cfg.Apps {
		cfg.Apps[i].Package = strings.TrimSpace(cfg.Apps[i].Package)
		if cfg.Apps[i].Package == "" {
			return fmt.Errorf("apps[%d] ไม่มี package", i)
		}
		if cfg.Apps[i].Name == "" {
			cfg.Apps[i].Name = cfg.Apps[i].Package
		}
	}
	return os.MkdirAll(filepath.Dir(cfg.LogFile), 0755)
}

func renderAndCheck() {
	statuses := make([]AppStatus, 0, len(cfg.Apps))
	for _, app := range cfg.Apps {
		if !app.Enabled {
			statuses = append(statuses, AppStatus{App: app, Action: "DISABLED"})
			continue
		}
		pids := findPIDs(app.Package)
		status := AppStatus{App: app, Running: pids != "", PIDs: pids, Action: "MONITOR"}
		if status.Running {
			status.Action = "RUNNING"
		} else if app.AutoRestart {
			if err := launchApp(app.Package); err != nil {
				status.Action = "LAUNCH FAILED"
				logf("ERROR", "launch %s (%s): %v", app.Name, app.Package, err)
			} else {
				status.Action = "LAUNCH SENT"
				logf("WARN", "app not running; launch requested: %s (%s)", app.Name, app.Package)
			}
		} else {
			status.Action = "STOPPED"
		}
		statuses = append(statuses, status)
	}
	drawDashboard(statuses)
}

func findPIDs(pkg string) string {
	// Android's pidof is preferred. Fall back to parsing ps output.
	for _, bin := range []string{"/system/bin/pidof", "pidof"} {
		out, err := exec.Command(bin, pkg).Output()
		if err == nil && strings.TrimSpace(string(out)) != "" {
			return strings.TrimSpace(string(out))
		}
	}
	out, err := exec.Command("ps", "-A").Output()
	if err != nil {
		return ""
	}
	var found []string
	for _, line := range strings.Split(string(out), "\n") {
		fields := strings.Fields(line)
		if len(fields) < 2 {
			continue
		}
		// Android ps formats commonly put PID in column 2.
		pid := fields[1]
		if _, err := strconv.Atoi(pid); err != nil {
			continue
		}
		if fields[len(fields)-1] == pkg || strings.HasPrefix(fields[len(fields)-1], pkg+":") {
			found = append(found, pid)
		}
	}
	return strings.Join(found, " ")
}

func launchApp(pkg string) error {
	// Opens the app's launcher activity; it does not force-stop other apps.
	cmd := exec.Command("monkey", "-p", pkg, "1")
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("%w: %s", err, strings.TrimSpace(string(out)))
	}
	return nil
}

func drawDashboard(statuses []AppStatus) {
	clearScreen()
	fmt.Println("\033[1;36m╔══════════════════════════════════════════════════════════════════════╗\033[0m")
	fmt.Println("\033[1;36m║                    NEFREJOIN GO | TERMUX DASHBOARD                   ║\033[0m")
	fmt.Println("\033[1;36m╚══════════════════════════════════════════════════════════════════════╝\033[0m")
	fmt.Printf(" เวลา: %-20s รอบตรวจ: %ds   ระบบ: %s/%s\n", time.Now().Format("2006-01-02 15:04:05"), cfg.RefreshSeconds, runtime.GOOS, runtime.GOARCH)
	fmt.Println(strings.Repeat("─", 74))
	fmt.Printf("%-17s %-30s %-14s %s\n", "APP", "PACKAGE", "STATUS", "PID")
	fmt.Println(strings.Repeat("─", 74))
	for _, s := range statuses {
		status := s.Action
		color := "\033[33m"
		switch s.Action {
		case "RUNNING":
			color = "\033[32m"
		case "STOPPED", "LAUNCH FAILED":
			color = "\033[31m"
		case "DISABLED":
			color = "\033[90m"
		case "LAUNCH SENT":
			color = "\033[36m"
		}
		pid := s.PIDs
		if pid == "" {
			pid = "-"
		}
		fmt.Printf("%-17s %-30s %s%-14s\033[0m %s\n", cut(s.App.Name, 17), cut(s.App.Package, 30), color, status, pid)
	}
	fmt.Println(strings.Repeat("─", 74))
	fmt.Println("Config: config.json | Log: " + cfg.LogFile)
	fmt.Println("Auto restart จะทำงานเฉพาะรายการที่ตั้ง \"auto_restart\": true")
	fmt.Println("กด Ctrl+C เพื่อหยุดการตรวจสอบ")
}

func clearScreen() {
	fmt.Print("\033[H\033[2J")
}

func cut(s string, n int) string {
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	if n <= 1 {
		return string(r[:n])
	}
	return string(r[:n-1]) + "…"
}

func logf(level, format string, args ...any) {
	msg := fmt.Sprintf(format, args...)
	line := fmt.Sprintf("%s [%s] %s\n", time.Now().Format(time.RFC3339), level, msg)
	fmt.Print(line)
	if cfg.LogFile == "" {
		return
	}
	if err := os.MkdirAll(filepath.Dir(cfg.LogFile), 0755); err != nil {
		return
	}
	f, err := os.OpenFile(cfg.LogFile, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	_, _ = f.WriteString(line)
}
