# nefrejoin-go (Termux)

โปรเจกต์ Go แบบไม่ใช้ไลบรารีภายนอก มี Dashboard, config หลาย Package และ log

## ติดตั้ง

```bash
pkg update -y
pkg install golang -y
```

## ตั้งค่า

แก้ไฟล์ `config.json`:

- `name`: ชื่อที่แสดงใน Dashboard
- `package`: Android package name ของแอป
- `enabled`: เปิด/ปิดการตรวจสอบรายการนี้
- `auto_restart`: ถ้าเป็น `true` จะสั่งเปิดแอปเมื่อไม่พบ process
- `refresh_seconds`: ระยะเวลาตรวจสอบ
- `log_file`: ตำแหน่งไฟล์ log

ปิดรายการตัวอย่างที่ยังไม่มี Package จริง หรือแทนค่าด้วย package name ที่ถูกต้อง

## รัน

```bash
go run main.go
```

## Build

```bash
go build -o nefrejoin
./nefrejoin
```

## หมายเหตุ

- ตรวจ process ด้วย `pidof` และ fallback ไป `ps -A`
- เปิดแอปผ่าน `monkey -p PACKAGE 1`
- Android อาจจำกัดการเปิดแอปเบื้องหลัง และบางแอปอาจไม่มี launcher activity
- `auto_restart` เป็นการส่งคำสั่งเปิดแอปเมื่อ process หาย ไม่ได้ตรวจจับ Error Code ภายในเกม
- ค่าเริ่มต้นปิด `auto_restart` เพื่อให้ทดสอบ Package ก่อน
- ใช้ package name ของแอปที่ติดตั้งจริงเท่านั้น
