module nefrejoin-go

go 1.22
